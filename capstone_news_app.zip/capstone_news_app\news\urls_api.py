from django.urls import path
from .api_views import ArticleListAPI

urlpatterns = [
    path('articles/', ArticleListAPI.as_view(), name='api_articles'),
]
from django.db import models
from rest_framework.generics import ListAPIView
from rest_framework.permissions import IsAuthenticated
from .models import Article
from .serializers import ArticleSerializer

class ArticleListAPI(ListAPIView):
    serializer_class = ArticleSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        # Get articles from subscribed publishers and journalists
        subscribed_publishers = user.subscribed_publishers.all()
        subscribed_journalists = user.subscribed_journalists.all()
        qs = Article.objects.filter(approved=True).order_by('-published_at')
        qs = qs.filter(
            models.Q(publisher__in=subscribed_publishers) | models.Q(author__in=subscribed_journalists)
        )
        return qs
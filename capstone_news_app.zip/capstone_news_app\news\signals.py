from django.conf import settings
from django.core.mail import send_mass_mail
from django.db.models.signals import pre_save, post_save
from django.dispatch import receiver
from .models import Article
import requests

# helper to get subscribers (publisher subscribers + journalist subscribers)
def _gather_subscriber_emails(article):
    emails = set()
    if article.publisher:
        emails.update(article.publisher.subscribers.values_list('email', flat=True))
    # subscribers to article author (journalist)
    emails.update(article.author.subscriber_of.values_list('email', flat=True))
    return [e for e in emails if e]

@receiver(pre_save, sender=Article)
def article_pre_save(sender, instance, **kwargs):
    # store prior approved state on instance for post_save to detect change
    if instance.pk:
        try:
            previous = sender.objects.get(pk=instance.pk)
            instance._was_approved = previous.approved
        except sender.DoesNotExist:
            instance._was_approved = False
    else:
        instance._was_approved = False

@receiver(post_save, sender=Article)
def article_post_save(sender, instance, created, **kwargs):
    # if article has just been approved, notify subscribers and post to X
    if not getattr(instance, '_was_approved', False) and instance.approved:
        # send email to subscribers
        emails = _gather_subscriber_emails(instance)
        if emails:
            subject = f"New article published: {instance.title}"
            message = instance.body[:500] + "\n\nRead more on the site."
            from_email = settings.DEFAULT_FROM_EMAIL
            datatuple = [(subject, message, from_email, [email]) for email in emails]
            send_mass_mail(datatuple, fail_silently=True)

        # post to X (Twitter) via HTTP API - placeholder
        try:
            x_api_url = getattr(settings, 'X_API_POST_URL', None)
            x_bearer = getattr(settings, 'X_API_BEARER', None)
            if x_api_url and x_bearer:
                headers = {"Authorization": f"Bearer {x_bearer}", "Content-Type": "application/json"}
                payload = {"text": f"{instance.title}\n{instance.body[:240]}"}
                requests.post(x_api_url, json=payload, headers=headers, timeout=5)
        except Exception:
            # intentionally silent; production should log
            pass